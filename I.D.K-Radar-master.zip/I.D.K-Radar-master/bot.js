const discord = new require("discord.js");
const client = new discord.Client();
const prefix = "-";
client.on('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
	client.user.setGame('🎉Im Watching you 🎆',"https://www.twitch.tv/peery13");
});

var config = {
  events: [
    {type: "CHANNEL_CREATE", logType: "CHANNEL_CREATE", limit: 2 , delay: 6000},
    {type: "CHANNEL_DELETE", logType: "CHANNEL_DELETE", limit: 2, delay: 5000},
    {type: "GUILD_MEMBER_REMOVE", logType: "MEMBER_KICK", limit: 2, delay: 5000},
    {type: "GUILD_BAN_ADD", logType: "MEMBER_BAN_ADD", limit: 2, delay: 5000},
    {type: "GUILD_ROLE_CREATE", logType: "ROLE_CREATE", limit: 2, delay: 5000},
    {type: "GUILD_ROLE_DELETE", logType: "ROLE_DELETE", limit: 2, delay: 5000},
  ]
}


	
	
client.on("error", (e) => console.error(e));
client.on("raw", (packet)=> {
  let {t, d} = packet, type = t, {guild_id} = data = d || {};
  if (type === "READY") {
    client.startedTimestamp = new Date().getTime();
    client.captures = [];
  }
  let event = config.events.find(anEvent => anEvent.type === type);
  if (!event) return;
  let guild = client.guilds.get(guild_id);
  if (!guild) return;
  guild.fetchAuditLogs({limit : 1, type: event.logType})
    .then(eventAudit => {
      let eventLog = eventAudit.entries.first();
      if (!eventLog) return;
      let executor = eventLog.executor;
      guild.fetchAuditLogs({type: event.logType, user: executor})
        .then((userAudit, index) => {
          let uses = 0;
          userAudit.entries.map(entry => {
            if (entry.createdTimestamp > client.startedTimestamp && !client.captures.includes(index)) uses += 1;
          });
          setTimeout(() => {
            client.captures[index] = index
          }, event.delay || 2000)
          if (uses >= event.limit) {
            client.emit("reachLimit", {
              user: userAudit.entries.first().executor,
              member: guild.members.get(executor.id),
              guild: guild,
              type: event.type,
            })
          }
        }).catch(console.error)
    }).catch(console.error)
});
client.on("reachLimit", (limit)=> {
	if(limit.user.id == "402556850224103445") return;
let log = limit.guild.channels.find( channel => channel.name === "radar-bas");

         
log.send("__** warning :warning::**__ " + " ``" + limit.user.username + "`` " + " ** tried to do something :rotating_light: ** https://thumbs.gfycat.com/WearyEasygoingBunting-size_restricted.gif ");
        
limit.guild.owner.send("__** warning :warning::**__ " + " ``" + limit.user.username + "`` " + "** tried to do something :rotating_light: **  ");
limit.member.roles.map(role => {
limit.member.ban(role.id).catch(log.send)
  });
  
  
});
client.on('message', msg => {
    if (msg.content == 'ping') {
        msg.reply('pong!');
    }
});


client.on('guildMemberAdd', (mem) => {
   
     if (mem.user.bot) {
 let log = mem.guild.channels.find( channel => channel.name === "verification-log");
 log.send("__**Warning**__:warning: **: This bot** ``" + mem.displayName + "`` **has not been verified** :robot: :rotating_light:  ");
   mem.ban(7)
  .then(() => log.send("``" + mem.displayName + "``** has banned :hammer: **") )
 mem.guild.owner.send("__**warning :warning::**__**There is unknown bot joined to** ``" + mem.guild.name + "`` **as** ``" + mem.displayName + "`` :rotating_light:" );
     }
    
     
})

client.on('guildMemberAdd', (mem1) => {
             if ( (mem1.user.id == "537147937583529994") || (mem1.user.id == "484891046917177345") || (mem1.user.id == "603359781238997011") || (mem1.user.id == "368836498709020684") || (mem1.user.id == "564180156722184202")  || (mem1.user.id == "596834067870121985")|| (mem1.user.id == "574696473028067349")|| (mem1.user.id == "611370212423368704")|| (mem1.user.id == "587043443767902231")|| (mem1.user.id == "")){
		let chan = mem1.guild.channels.find( channel => channel.id === "620781295563177985");
                chan.send("__**Warning :warning: :**__**This member ``" + mem1.displayName + "`` is blacklisted:rotating_light: ** ");
		mem1.ban(7) 
                .then(() => chan.send(" ``" + mem1.displayName + " `` __**was banned :hammer:**__"));
	        mem1.guild.owner.send("__**Warning :warning: :**__**This member** ``" + mem1.displayName + "`` ** has been banned because it is blacklisted:rotating_light: **");
}
});

client.on('message', msg => {
if (msg.content.startsWith(prefix + 'scann')) {
	if(!msg.member.hasPermission('ADMINISTRATOR')) return msg.channel.send('**you dont have permission** `ADMINISTRATOR`🚫' );

msg.guild.ban('564180156722184202').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('596834067870121985').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('611370212423368704').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('537147937583529994').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('484891046917177345').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('603359781238997011').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('368836498709020684').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `));
msg.guild.ban('587043443767902231').then(user => msg.channel.send(`**🚨Blacklisted user detected :** __** ${user.username || user.id || user}**__ **has been banned from**🔨 __** ${msg.guild.name} **__ `))
    
.then(user2 => msg.channel.send('__**The server is clean**__✅'));
}
});



client.on('message', message => {
  if (!message.content.startsWith(prefix)) return;
  var args = message.content.split(' ').slice(1);
  var argresult = args.join(' ');
  if (message.author.id !== "402556850224103445") return;

  
  if (message.content.startsWith(prefix + 'setwatch')) {
  client.user.setActivity(argresult, {type: 'WATCHING'})
     console.log('test' + argresult);
    message.channel.sendMessage(`Watch Now: **${argresult}`)
} 

 
  if (message.content.startsWith(prefix + 'setlis')) {
  client.user.setActivity(argresult, {type: 'LISTENING'})
     console.log('test' + argresult);
    message.channel.sendMessage(`LISTENING Now: **${argresult}`)
} 


if (message.content.startsWith(prefix + 'setname')) {
  client.user.setUsername(argresult).then
      message.channel.sendMessage(`Username Changed To **${argresult}**`)
  return message.reply("You Can change the username 2 times per hour");
} 



if (message.content.startsWith(prefix + 'setT')) {
  client.user.setGame(argresult, "https://www.twitch.tv/peery13");
     console.log('test' + argresult);
    message.channel.sendMessage(`Streaming: **${argresult}`)
} 
if (message.content.startsWith(prefix + 'setgame')) {
  client.user.setGame(argresult);
     console.log('test' + argresult);
    message.channel.sendMessage(`Playing: **${argresult}`)
} 



});




client.login(process.env.BOT_TOKEN);
